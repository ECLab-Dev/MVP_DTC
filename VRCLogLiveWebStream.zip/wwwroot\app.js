document.addEventListener("DOMContentLoaded", () => {
    const wsUrl = `ws://${window.location.host}/ws`;
    let socket;

    const logConsole = document.getElementById("logConsole");
    const surveyCardsContainer = document.getElementById("surveyCardsContainer");
    const detectedCountEl = document.getElementById("detectedCount");
    const statusMessageEl = document.getElementById("statusMessage");
    const statusIndicatorEl = document.getElementById("statusIndicator");

    const userNameInput = document.getElementById("userName");
    const uploadUrlInput = document.getElementById("uploadUrl");
    const apiKeyInput = document.getElementById("apiKey");
    const radarRangeInput = document.getElementById("radarRange");
    const rangeValueEl = document.getElementById("rangeValue");
    const centerPlayerInput = document.getElementById("centerPlayer");
    const saveConfigBtn = document.getElementById("saveConfigBtn");
    const clearLogBtn = document.getElementById("clearLogBtn");

    const canvas = document.getElementById("radarCanvas");
    const ctx = canvas ? canvas.getContext("2d") : null;

    const playerPositions = {};
    let sweepAngle = 0;

    const knownPlayerNames = new Set();

    function updateCenterPlayerDropdown(newName) {
        if (!centerPlayerInput || !newName) return;
        if (knownPlayerNames.has(newName)) return;

        knownPlayerNames.add(newName);

        const currentSelected = centerPlayerInput.value;
        const opt = document.createElement("option");
        opt.value = newName;
        opt.textContent = newName;
        centerPlayerInput.appendChild(opt);

        if (currentSelected) {
            centerPlayerInput.value = currentSelected;
        }
    }

    // LocalStorage から設定を読み込み (アプリ設定のみ永続化)
    function loadSavedConfig() {
        const savedUserName = localStorage.getItem("vrclog_userName");
        const savedUploadUrl = localStorage.getItem("vrclog_uploadUrl");
        const savedApiKey = localStorage.getItem("vrclog_apiKey");

        if (savedUserName && userNameInput) userNameInput.value = savedUserName;
        if (savedUploadUrl && uploadUrlInput) uploadUrlInput.value = savedUploadUrl;
        if (savedApiKey && apiKeyInput) apiKeyInput.value = savedApiKey;
    }

    function sendConfigToBackend(saveToFile = false) {
        if (!socket || socket.readyState !== WebSocket.OPEN) return;

        const userName = userNameInput ? userNameInput.value.trim() : "";
        const uploadUrl = uploadUrlInput ? uploadUrlInput.value.trim() : "";
        const apiKey = apiKeyInput ? apiKeyInput.value.trim() : "";
        const radarRange = radarRangeInput ? parseFloat(radarRangeInput.value) || 50 : 50;
        const centerPlayer = centerPlayerInput ? centerPlayerInput.value.trim() : "";

        // アプリケーション設定（送信設定のみ永続保存フラグ）
        socket.send(JSON.stringify({
            type: "SET_UPLOAD_CONFIG",
            username: userName,
            uploadUrl: uploadUrl,
            apiKey: apiKey,
            saveToFile: saveToFile
        }));

        // レーダー範囲・中心プレイヤーは一時表示設定
        socket.send(JSON.stringify({
            type: "SET_RADAR_SCALE",
            rangeMeters: radarRange,
            saveToFile: false
        }));

        socket.send(JSON.stringify({
            type: "SET_RADAR_CENTER",
            centerPlayer: centerPlayer,
            saveToFile: false
        }));
    }

    loadSavedConfig();

    function connectWebSocket() {
        socket = new WebSocket(wsUrl);

        socket.onopen = () => {
            console.log("[WebSocket] 接続成功");
            statusMessageEl.textContent = "ストリーミング接続中";
            statusIndicatorEl.className = "status-indicator success";
            appendLog("SYSTEM", "WebSocket 接続が確立されました", "system");
        };

        socket.onmessage = (event) => {
            try {
                if (event.data.startsWith("{") && event.data.includes("INIT_CONFIG")) {
                    const data = JSON.parse(event.data);
                    if (data.type === "INIT_CONFIG") {
                        const userVal = data.username || "DefaultUser";
                        const urlVal = data.uploadUrl || "";
                        const keyVal = data.apiKey || "";

                        if (userNameInput) userNameInput.value = userVal;
                        if (uploadUrlInput) uploadUrlInput.value = urlVal;
                        if (apiKeyInput) apiKeyInput.value = keyVal;

                        localStorage.setItem("vrclog_userName", userVal);
                        localStorage.setItem("vrclog_uploadUrl", urlVal);
                        localStorage.setItem("vrclog_apiKey", keyVal);
                        return;
                    }
                }
            } catch (e) { }

            const lines = event.data.split("\n");
            lines.forEach((line) => {
                if (!line.trim()) return;

                if (line.includes("[MVP_Q]")) {
                    appendLog("SURVEY", line, "survey");
                    renderSurveyCard(line);
                } else if (line.includes("[MVP_DTC]")) {
                    appendLog("RADAR", line, "radar");
                    parseAndStorePosition(line);
                } else if (line.includes("OnPlayerJoined") || line.includes("User joined")) {
                    appendLog("JOIN", line, "join");
                } else if (line.includes("OnPlayerLeft") || line.includes("User left")) {
                    appendLog("LEFT", line, "left");
                } else {
                    appendLog("VRCLog", line, "normal");
                }
            });
        };

        socket.onclose = () => {
            console.warn("[WebSocket] 切断されました。3秒後に再接続します...");
            statusMessageEl.textContent = "切断されました。再接続中...";
            statusIndicatorEl.className = "status-indicator danger";
            setTimeout(connectWebSocket, 3000);
        };

        socket.onerror = (err) => {
            console.error("[WebSocket] エラー:", err);
        };
    }

    function parseAndStorePosition(message) {
        try {
            const regexCoords = /\((-?\d+\.\d+),\s*(-?\d+\.\d+),\s*(-?\d+\.\d+)\)/g;
            const matches = [...message.matchAll(regexCoords)];

            if (matches.length >= 3) {
                const posMatch = matches[2];
                const x = parseFloat(posMatch[1]);
                const z = parseFloat(posMatch[3]);

                let name = "Player";
                const regexName = /([a-zA-Z0-9_-]+):\s*\d+:\s*\(/;
                const nameMatch = message.match(regexName);
                if (nameMatch) {
                    name = nameMatch[1];
                }

                playerPositions[name] = {
                    name: name,
                    x: x,
                    z: z,
                    lastUpdated: Date.now()
                };

                if (name && name !== "Player") {
                    updateCenterPlayerDropdown(name);
                }
            }
        } catch (e) { }
    }

    function drawRadar() {
        if (!ctx || !canvas) return;

        const w = canvas.width;
        const h = canvas.height;
        const cx = w / 2;
        const cy = h / 2;
        const radius = Math.min(cx, cy) - 30;

        ctx.clearRect(0, 0, w, h);

        // レーダー背景
        ctx.fillStyle = "#121722";
        ctx.fillRect(0, 0, w, h);

        // 同心円
        ctx.strokeStyle = "rgba(0, 243, 255, 0.25)";
        ctx.lineWidth = 1;
        ctx.setLineDash([4, 4]);

        [0.25, 0.5, 0.75, 1.0].forEach(rRatio => {
            ctx.beginPath();
            ctx.arc(cx, cy, radius * rRatio, 0, Math.PI * 2);
            ctx.stroke();
        });

        // 十字軸
        ctx.beginPath();
        ctx.moveTo(cx - radius, cy); ctx.lineTo(cx + radius, cy);
        ctx.moveTo(cx, cy - radius); ctx.lineTo(cx, cy + radius);
        ctx.stroke();
        ctx.setLineDash([]);

        // 方位ラベル
        ctx.fillStyle = "#00f3ff";
        ctx.font = "bold 11px Consolas, sans-serif";
        ctx.fillText("N (Z+)", cx - 18, cy - radius - 10);
        ctx.fillText("S (Z-)", cx - 18, cy + radius + 18);
        ctx.fillText("E (X+)", cx + radius + 8, cy + 4);
        ctx.fillText("W (X-)", cx - radius - 45, cy + 4);

        // スキャンライン (スイープ)
        sweepAngle = (sweepAngle + 0.05) % (Math.PI * 2);
        const endX = cx + Math.cos(sweepAngle) * radius;
        const endY = cy + Math.sin(sweepAngle) * radius;

        ctx.strokeStyle = "rgba(0, 243, 255, 0.6)";
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(cx, cy);
        ctx.lineTo(endX, endY);
        ctx.stroke();

        // プレイヤープロット
        const radarRange = radarRangeInput ? parseFloat(radarRangeInput.value) || 50 : 50;
        const centerName = centerPlayerInput ? centerPlayerInput.value.trim() : "";

        let originX = 0, originZ = 0;
        if (centerName && playerPositions[centerName]) {
            originX = playerPositions[centerName].x;
            originZ = playerPositions[centerName].z;
        }

        const now = Date.now();
        let activeCount = 0;

        Object.values(playerPositions).forEach(p => {
            if (now - p.lastUpdated > 180000) return;
            activeCount++;

            const relX = p.x - originX;
            const relZ = p.z - originZ;
            const worldRange = radarRange * 2;

            let px = cx + (relX / worldRange) * (radius * 2);
            let py = cy - (relZ / worldRange) * (radius * 2);

            px = Math.max(cx - radius + 5, Math.min(cx + radius - 5, px));
            py = Math.max(cy - radius + 5, Math.min(cy + radius - 5, py));

            ctx.fillStyle = (p.name.includes("Sakurada") || p.name.includes("Me")) ? "#ff00ff" : "#00ffcc";
            ctx.beginPath();
            ctx.arc(px, py, 6, 0, Math.PI * 2);
            ctx.fill();
            ctx.strokeStyle = "#ffffff";
            ctx.lineWidth = 1;
            ctx.stroke();

            ctx.fillStyle = "#ffffff";
            ctx.font = "bold 10px Meiryo, sans-serif";
            ctx.fillText(p.name, px + 8, py + 3);
        });

        if (detectedCountEl) {
            detectedCountEl.textContent = activeCount;
        }

        requestAnimationFrame(drawRadar);
    }

    function appendLog(tag, text, typeClass) {
        const timeStr = new Date().toLocaleTimeString();
        const div = document.createElement("div");
        div.className = `log-entry ${typeClass}`;
        div.innerHTML = `<span class="time">[${timeStr}]</span> <span class="tag">[${tag}]</span> ${escapeHtml(text)}`;
        logConsole.appendChild(div);

        while (logConsole.children.length > 100) {
            logConsole.removeChild(logConsole.firstChild);
        }
        logConsole.scrollTop = logConsole.scrollHeight;
    }

    function renderSurveyCard(rawLog) {
        const emptyNotice = surveyCardsContainer.querySelector(".empty-survey-notice");
        if (emptyNotice) {
            emptyNotice.remove();
        }

        const tagIdx = rawLog.indexOf("[MVP_Q]");
        if (tagIdx < 0) return;

        const body = rawLog.substring(tagIdx + 7).trim();
        const colonIdx = body.indexOf(":");
        if (colonIdx < 0) return;

        const playerName = body.substring(0, colonIdx).trim();
        const qContent = body.substring(colonIdx + 1).trim();
        const timeStr = new Date().toLocaleTimeString();

        const card = document.createElement("div");
        card.className = "survey-card-item";

        let answersHtml = "";
        const qBlocks = qContent.split("|");

        qBlocks.forEach((block) => {
            const trimmed = block.trim();
            if (!trimmed) return;

            const parts = trimmed.split(":");
            let qNum = "Q", qTitle = "質問", aType = "形式", aContent = trimmed;

            if (parts.length >= 4) {
                qNum = parts[0].trim();
                qTitle = parts[1].trim();
                aType = parts[2].trim();
                aContent = parts[3].trim();
            } else if (parts.length === 3) {
                qNum = parts[0].trim();
                qTitle = parts[0].trim();
                aType = parts[1].trim();
                aContent = parts[2].trim();
            }

            let badgeClass = "badge-choice";
            if (aType.includes("スライダー") || aType.includes("評価")) badgeClass = "badge-slider";
            if (aType.includes("記述") || aType.includes("入力")) badgeClass = "badge-text";

            answersHtml += `
                <div class="answer-row">
                    <span class="type-badge ${badgeClass}">${escapeHtml(qNum)} [${escapeHtml(aType)}]</span>
                    <span class="q-title">${escapeHtml(qTitle)}</span>
                    <span class="a-content">${escapeHtml(aContent)}</span>
                </div>
            `;
        });

        card.innerHTML = `
            <div class="survey-card-header">
                <span class="player-icon">👤</span>
                <span class="player-name">${escapeHtml(playerName)}</span>
                <span class="answer-time">${timeStr}</span>
            </div>
            <div class="survey-card-body">
                ${answersHtml}
            </div>
        `;

        surveyCardsContainer.insertBefore(card, surveyCardsContainer.firstChild);

        while (surveyCardsContainer.children.length > 20) {
            surveyCardsContainer.removeChild(surveyCardsContainer.lastChild);
        }
    }

    function escapeHtml(str) {
        return str.replace(/[&<>"']/g, (m) => {
            return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;" }[m];
        });
    }

    function saveAllSettings(showFeedback = true) {
        const userName = userNameInput ? userNameInput.value.trim() : "";
        const uploadUrl = uploadUrlInput ? uploadUrlInput.value.trim() : "";
        const apiKey = apiKeyInput ? apiKeyInput.value.trim() : "";

        localStorage.setItem("vrclog_userName", userName);
        localStorage.setItem("vrclog_uploadUrl", uploadUrl);
        localStorage.setItem("vrclog_apiKey", apiKey);

        sendConfigToBackend(showFeedback);

        if (showFeedback) {
            appendLog("SYSTEM", "✅ アプリ設定をローカルファイル(config-live.json)に保存しました。", "system");
            if (saveConfigBtn) {
                const originalText = saveConfigBtn.innerHTML;
                const originalBg = saveConfigBtn.style.backgroundColor;
                saveConfigBtn.innerHTML = "✅ 保存完了！";
                saveConfigBtn.style.backgroundColor = "#00e676";
                saveConfigBtn.style.color = "#000000";

                setTimeout(() => {
                    saveConfigBtn.innerHTML = originalText;
                    saveConfigBtn.style.backgroundColor = originalBg;
                    saveConfigBtn.style.color = "";
                }, 2000);
            }
        }
    }

    if (radarRangeInput) {
        radarRangeInput.addEventListener("input", (e) => {
            if (rangeValueEl) rangeValueEl.textContent = e.target.value;
            sendConfigToBackend(false);
        });
    }

    if (centerPlayerInput) {
        centerPlayerInput.addEventListener("change", () => {
            sendConfigToBackend(false);
        });
    }

    if (userNameInput) userNameInput.addEventListener("change", () => saveAllSettings(false));
    if (uploadUrlInput) uploadUrlInput.addEventListener("change", () => saveAllSettings(false));
    if (apiKeyInput) apiKeyInput.addEventListener("change", () => saveAllSettings(false));

    if (saveConfigBtn) {
        saveConfigBtn.addEventListener("click", () => {
            saveAllSettings(true);
        });
    }

    const resetConfigBtn = document.getElementById("resetConfigBtn");
    if (resetConfigBtn) {
        resetConfigBtn.addEventListener("click", () => {
            if (userNameInput) userNameInput.value = "DefaultUser";
            if (uploadUrlInput) uploadUrlInput.value = "";
            if (apiKeyInput) apiKeyInput.value = "";

            localStorage.removeItem("vrclog_userName");
            localStorage.removeItem("vrclog_uploadUrl");
            localStorage.removeItem("vrclog_apiKey");

            saveAllSettings(true);
            appendLog("SYSTEM", "🔄 アプリ設定およびローカル保存を完全リセットしました。", "system");
        });
    }

    if (clearLogBtn) {
        clearLogBtn.addEventListener("click", () => {
            logConsole.innerHTML = "";
        });
    }

    connectWebSocket();
    requestAnimationFrame(drawRadar);
});
